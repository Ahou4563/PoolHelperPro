package com.example.poolhelperpro;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private LinearLayout panel;
    private WindowManager.LayoutParams lp;
    private int downX, downY, startX, startY;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate() {
        super.onCreate();

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        int width = dp(190);
        int height = dp(190);

        lp = new WindowManager.LayoutParams(
                width,
                height,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(12);
        lp.y = dp(100);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(6), dp(6), dp(6), dp(6));
        panel.setBackgroundColor(0xDD222222);

        TextView title = new TextView(this);
        title.setText("🎱 هدف‌یار");
        title.setTextColor(Color.WHITE);
        title.setTextSize(16);
        title.setGravity(Gravity.CENTER);
        panel.addView(title, new LinearLayout.LayoutParams(-1, dp(50)));

        Button help = new Button(this);
        help.setText("راهنما");
        help.setOnClickListener(v ->
                title.setText("توپ‌ها را روی ابزار علامت بزن؛ سپس خط نشانه را ببین.")
        );
        panel.addView(help, new LinearLayout.LayoutParams(-1, dp(50)));

        Button close = new Button(this);
        close.setText("بستن");
        close.setOnClickListener(v -> stopSelf());
        panel.addView(close, new LinearLayout.LayoutParams(-1, dp(50)));

        title.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX = (int) e.getRawX();
                downY = (int) e.getRawY();
                startX = lp.x;
                startY = lp.y;
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                lp.x = startX + (int) e.getRawX() - downX;
                lp.y = startY + (int) e.getRawY() - downY;
                try {
                    wm.updateViewLayout(panel, lp);
                } catch (Exception ignored) {
                }
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_UP) {
                v.performClick();
                return true;
            }
            return true;
        });

        try {
            wm.addView(panel, lp);
        } catch (Exception e) {
            panel = null;
            stopSelf();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (panel != null && wm != null) {
            try {
                wm.removeView(panel);
            } catch (Exception ignored) {
            }
        }
        panel = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
