package com.example.poolhelperpro;
import android.content.*; import android.graphics.*; import android.util.AttributeSet; import android.view.*;
public class TableView extends View {
 Paint p=new Paint(1); float wx=-1,wy=-1,tx=-1,ty=-1; int mode=0; MainActivity a;
 public TableView(Context c){this(c,null);}
 public TableView(Context c, AttributeSet attrs){super(c,attrs); init(c);}
 public TableView(Context c, AttributeSet attrs, int defStyleAttr){super(c,attrs,defStyleAttr); init(c);}
 private void init(Context c){ a = (c instanceof MainActivity) ? (MainActivity)c : null; p.setStrokeWidth(5); setBackgroundColor(Color.rgb(35,35,35));}
 protected void onDraw(Canvas c){super.onDraw(c); float L=30,T=30,R=getWidth()-30,B=getHeight()-30;
  p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(20,110,65)); c.drawRoundRect(L,T,R,B,25,25,p);
  p.setColor(Color.DKGRAY); for(float[] q:new float[][]{{L,T},{R,T},{L,B},{R,B},{(L+R)/2,T},{(L+R)/2,B}}) c.drawCircle(q[0],q[1],13,p);
  if(wx>=0){p.setColor(Color.WHITE);c.drawCircle(wx,wy,11,p);}
  if(tx>=0){p.setColor(Color.rgb(220,50,50));c.drawCircle(tx,ty,11,p);}
  if(wx>=0&&tx>=0){p.setStyle(Paint.Style.STROKE);p.setColor(Color.YELLOW);p.setStrokeWidth(5);c.drawLine(wx,wy,tx,ty,p);p.setStyle(Paint.Style.FILL);}
 }
 public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=1)return true; float x=e.getX(),y=e.getY();
  if(mode==0){wx=x;wy=y;mode=1;if(a!=null)a.updateInfo("حالا توپ هدف را لمس کنید.");}
  else {tx=x;ty=y;mode=0; double ang=Math.toDegrees(Math.atan2(-(ty-wy),tx-wx)); if(ang<0)ang+=360; double dist=Math.hypot(tx-wx,ty-wy);if(a!=null)a.updateInfo(String.format(java.util.Locale.US,"زاویه: %.1f°   فاصله: %.0f px",ang,dist));}
  invalidate(); return true;
 }
 public void reset(){wx=wy=tx=ty=-1;mode=0;invalidate();}
}