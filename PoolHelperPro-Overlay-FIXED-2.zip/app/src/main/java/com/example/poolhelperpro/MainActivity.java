package com.example.poolhelperpro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    TextView info;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        info = findViewById(R.id.info);
        Button permission = findViewById(R.id.permission);
        Button start = findViewById(R.id.start);
        Button stop = findViewById(R.id.stop);
        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else info.setText("مجوز نمایش روی برنامه‌ها فعال است.");
        });
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                info.setText("اول مجوز نمایش روی برنامه‌ها را فعال کنید.");
                return;
            }
            startService(new Intent(this, OverlayService.class));
            info.setText("ابزار شناور فعال شد. بازی را باز کنید.");
        });
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            info.setText("ابزار شناور خاموش شد.");
        });
    }
    public void updateInfo(String s) {
        if (info != null) info.setText(s);
    }
}
