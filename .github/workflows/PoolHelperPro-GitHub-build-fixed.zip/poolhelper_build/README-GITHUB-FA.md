# ساخت APK رایگان با GitHub Actions

این پروژه یک Workflow آماده دارد که روی GitHub اجرا می‌شود و فایل APK را به‌صورت Artifact تحویل می‌دهد.

مراحل از گوشی:
1. وارد GitHub شوید و یک Repository جدید بسازید، مثلاً `PoolHelperPro`.
2. فایل‌های داخل این پوشه را داخل Repository آپلود کنید؛ فایل ZIP را به‌صورت یک فایل تکی آپلود نکنید. باید پوشه‌های `app` و `.github` و فایل‌های `build.gradle` و `settings.gradle` در ریشه Repository باشند.
3. بعد از آپلود، به تب **Actions** بروید.
4. Workflow با نام **Build Pool Helper Pro APK** را باز کنید.
5. روی **Run workflow** بزنید و اجرای آن را شروع کنید.
6. وقتی سبز شد، وارد همان اجرای Workflow شوید و بخش **Artifacts** را باز کنید.
7. فایل `PoolHelperPro-debug` را دانلود و ZIP آن را باز کنید؛ داخلش `app-debug.apk` است.

GitHub فایل‌های خروجی Workflow را به‌عنوان Artifact نگه می‌دارد و از همان صفحه Actions قابل دانلود هستند.
