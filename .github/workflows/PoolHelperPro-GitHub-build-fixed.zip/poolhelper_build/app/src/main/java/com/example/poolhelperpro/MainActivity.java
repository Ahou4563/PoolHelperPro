package com.example.poolhelperpro;
import android.app.*; import android.os.*; import android.widget.*;
public class MainActivity extends Activity {
 TableView table; TextView info;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
 table=findViewById(R.id.table); info=findViewById(R.id.info);
 findViewById(R.id.reset).setOnClickListener(v->{table.reset();info.setText("توپ سفید را انتخاب کنید، سپس توپ هدف را لمس کنید.");});
 }
 public void updateInfo(String s){info.setText(s);}
}